<?php

class WC_OneFin_Payment_Gateway extends WC_Payment_Gateway
{
    /**
     * @var string
     */
    private $order_status;

    /**
     * WC_OneFin_Payment_Gateway constructor.
     */
    public function __construct()
    {
        $this->id = 'onefin_payment';
        $this->icon = sprintf("%s/assets/images/onefin.png",WC_ONEFIN_PLUGIN_URL);
        $this->method_title = __('OneFin Payment', WC_ONEFIN_PLUGIN_TEXT_DOMAIN);
        $this->title = __('OneFin Payment', WC_ONEFIN_PLUGIN_TEXT_DOMAIN);
        $this->has_fields = true;
        $this->init_form_fields();
        $this->init_settings();
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->method_description = 'Chuyển hướng tới OneFin Payment để thực hiện thanh toán.';
        $this->order_status = $this->get_option('order_status');
        $this->payment_submit_page = $this->get_option('payment_submit_page');
        $this->currency = $this->get_option('currency');
        $this->productCode = $this->get_option('productCode');
        $this->merEmail = $this->get_option('merEmail');
        $this->merMobile = $this->get_option('merMobile');
        $this->privateKey = $this->get_option('privateKey');
        $this->publicKey = $this->get_option('publicKey');
        $this->domain = $this->get_option('domain');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * init_form_fields
     */
    public function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'checkbox',
                'label' => __('Enable OneFin Payment', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Method Title', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'description' => __('This controls the title', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'default' => __('OneFin Payment', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'default' => __('OneFin Payment chuyển hướng khách hàng tới OneFin để nhập thông tin thanh toán.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'desc_tip' => true,
            ),
            'order_status' => array(
                'title' => __('Order Status After The Checkout', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'select',
                'options' => wc_get_order_statuses(),
                'default' => 'wc-processing',
                'description' => __('The default order status if this gateway used in payment.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'payment_submit_page' => array(
                'title' => __('Payment page', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'select',
                'default' => 368,
                'options' => $this->get_pages_list(),
                'description' => __('Page which proceed payment steps.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'currency' => array(
                'title' => __('Payment Currency', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'default' => 'VND',
                'desc_tip' => true,
                'description' => __('The default payment currency.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'productCode' => array(
                'title' => __('Product CODE (productCode)', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'default' => '0000000888231013141302157',
                'desc_tip' => true,
                'description' => __('Product CODE.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'merEmail' => array(
                'title' => __('Merchant Email (merEmail)', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'default' => 'thanhnguyen@onefin.vn',
                'desc_tip' => true,
                'description' => __('Merchant Email.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'merMobile' => array(
                'title' => __('Merchant Mobile (merMobile)', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'default' => '84933597587',
                'desc_tip' => true,
                'description' => __('Merchant Mobile.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'privateKey' => array(
                'title' => __('Checksum key (privateKey)', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'textarea',
                'default' => '-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDirIySPhE0r5qL
sz5to1K3hZ6BuGJpGbatWjxzIrWKwcH7QSrM7yTZ93nG7iEkueT99A1osAzucZI5
tT0W7Nwidyxm37eFqdj4+QZZSXgIUL1uHmMJJezJHsnHjGmKdm2XDcMCqsTJJedM
vzdzcnpD84ujsJh/9z8rExi6HNRjUT+LjnKhsYgfjhLqACjOsEpl/PzTYwx0XGoH
LViFiWJ4e5iHrMfqnv40gw4C5jih3JogBNqzTu1RUnPo033wFo9cA2szUCsa8N/S
/zMdCpSBiy1Gwp2JcGYDmbXtT/5t2gMWkPLlqKS1zV16IZwyTYYi3DjFiWGFrgWo
gyaxCv7NAgMBAAECggEBANxZGB1hsKAixH1hNSKnTdWRUtCPSTsZ//bsbS8PYqMM
T2HLq6ukHZK1e+/htN5axzwHbrGB0lBInvjyMfyDLEtkxgkLGQAaaA0/JujM/p42
vq65Y1SVRWUNROFyoXY0QbxBaHzDPKC88+grSeA0PJ6ptejd1qEu3H0nBzaEqAIS
OM9Hq0CU1SQHy+3aGilC5nnd7ZqkcUNuXk8ChKoBgu9HN9ERRgIqjJSo7ec9Kbmd
QI7shR6uA+r2EqSKO2mBm7QFaz94PEwQda3nvPZJjbUBlE3AaTZS7QJ8KolymNDz
E0W249nacdcjkjoDd2xor6afv7DQ7lU0txHvtCK0upECgYEA9zcMYEEm5Kg12xP8
RapbnTO0L3sswLqbVmp/UKFH6tTA9bfIyP8MYHN3bLZranMemtLvXX6sHN2bdFvU
SQerDIvlaqD1ANt7mA929TlsmanzU4T0tUVd9ORwMkp8VYNxYfNFSpJWFX0zBvv1
8HLuahwydickKeYmgh55GEA5w1sCgYEA6rqi2ekVja7wQYWHIEFa3aeJqQAfOx9S
tclUBX6dg/sQGf6kwDyIKFNSobtn0aStJMiOEjFL1L1a1+dG/YlLOxpvj69i+kSM
4pKZaaHyiqwRxxUgKKDtWOjcmWSR+Z8nXu27Ad32PEa94vepgNUN043bvS8FT6Tq
8T7Bt9PwJvcCgYBow4ZWICYYToSMM9r7tuceJnQcjwl3H12G8JjFlaOBi+m998V6
EEOxeB1LD79TnDeDCxLvPyg3D166n9PFox9EsOBnIJDTbS/iT+Nspoo0UIZShYyi
aSQZDNnTJiesoYhiJxLdOEiM0MLYGdyuqjYI96wW0B2ON/9nsvxEX6ta8wKBgCyv
MulA0fWS4/HVNZASYPXpOu+NMmTS5a/tj60sGVhSpxILw9lErLbghc58GptyOfPS
qhkUgVcSZQTM5lrFlCjAM5Sq0rDJ8/f96G6PgdicQRYhE2oomIZgbf5VguR+Q8Ry
hTMpygJXhTZ75yy7YlJvovE0zlIHFyKty7rvAbypAoGBAKcYIOBpnWO5dt5WwB+l
D1IWoJW9tdSkUSPtqDpLv1Q4vhUZx5AfejuLjUzdYLs+g82RJF8N+74GL25C0vhL
mCMTPEhwLvlKRrcJ0Vt7bTuD6MdAC92jW6yGB6UPQOLaATfgAZn0mzQpj3E4xtJ3
UWHBmGbogYTpfQb4jh+Hr375
-----END PRIVATE KEY-----',
                'desc_tip' => true,
                'description' => __('Checksum key (privateKey).', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'publicKey' => array(
                'title' => __('Checksum key (publicKey)', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'textarea',
                'default' => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzgDiF82nOVavtZ8AnyqJ
HEijRYpH9bJdSwISxYBsZojtRTE9c3JhDsCjQvwRKvkc79yRs5W5TZfqGjgarBwE
xUZ4WgP4hN/WV2ghW0Hi4dnbDsqhbkFYhErJUAfTGgMXp76t4Lc0y4UeJtRHmZhO
rzEK3imZpS7k4fLYl+CLRFN3xhvUY0JBVYxW3cUdP7H0NJ8I+wHjHPHF8Nxx2lyn
lbdHTxs1JA9z57AZi/kXpSJuW6RTT/QY+ENCNAUqYPWSay+orsNq8cXSNu3sIuGf
DEUfVzogjmN3Yu9mBMVmydokWz0PX/nmcTE3Wki2gC1e+E+rsjPs1K1+Xcs/ZVPy
yQIDAQAB
-----END PUBLIC KEY-----',
                'desc_tip' => true,
                'description' => __('Checksum key (publicKey).', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
            'domain' => array(
                'title' => __('Domain', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
                'type' => 'text',
                'default' => 'https://sit-pgw.onefin.vn/public/v3/mweb/',
                'desc_tip' => true,
                'description' => __('Domain.', WC_ONEFIN_PLUGIN_TEXT_DOMAIN),
            ),
        );
    }

    /**
     * @return array
     */
    public function get_pages_list()
    {
        $pages_array = array(__('Choose A Page', WC_ONEFIN_PLUGIN_TEXT_DOMAIN));
        $get_pages = get_pages('hide_empty=0');
        foreach ($get_pages as $page) {
            $pages_array[$page->ID] = esc_attr($page->post_title);
        }
        return $pages_array;
    }

    /**
     * Admin Panel Options
     * - Options for bits like 'title' and availability on a country-by-country basis
     *
     * @return void
     */
    public function admin_options()
    {
        ?>
        <h3><?php _e('OneFin Payment Settings', WC_ONEFIN_PLUGIN_TEXT_DOMAIN); ?></h3>
        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="post-body-content">
                    <table class="form-table">
                        <?php $this->generate_settings_html(); ?>
                    </table><!--/.form-table-->
                </div>

            </div>
        </div>
        <div class="clear"></div>
        <?php
    }

    /**
     * @param int $order_id
     * @return array
     */
    public function process_payment($order_id)
    {
        global $woocommerce;
        $order = new WC_Order($order_id);
        wc_reduce_stock_levels($order_id);
        $woocommerce->cart->empty_cart();
        $returnUrl = $this->get_return_url($order);
        if ($this->payment_submit_page) {
            $returnUrl = get_permalink($this->payment_submit_page) . '?order=' . $order_id;
        }
        return array(
            'result' => 'success',
            'redirect' => $returnUrl
        );
    }
}
