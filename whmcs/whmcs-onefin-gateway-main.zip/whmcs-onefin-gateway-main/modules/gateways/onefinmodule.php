<?php
/**
 * WHMCS Sample Payment Gateway Module
 *
 * Payment Gateway modules allow you to integrate payment solutions with the
 * WHMCS platform.
 *
 * This sample file demonstrates how a payment gateway module for WHMCS should
 * be structured and all supported functionality it can contain.
 *
 * Within the module itself, all functions must be prefixed with the module
 * filename, followed by an underscore, and then the function name. For this
 * example file, the filename is "onefinmodule" and therefore all functions
 * begin "onefinmodule_".
 *
 * If your module or third party API does not support a given function, you
 * should not define that function within your module. Only the _config
 * function is required.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related capabilities and
 * settings.
 *
 * @see https://developers.whmcs.com/payment-gateways/meta-data-params/
 *
 * @return array
 */
function onefinmodule_MetaData()
{
    return array(
        'DisplayName' => 'OneFin Payment Gateway',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    );
}

/**
 * Define gateway configuration options.
 *
 * The fields you define here determine the configuration options that are
 * presented to administrator users when activating and configuring your
 * payment gateway module for use.
 *
 * Supported field types include:
 * * text
 * * password
 * * yesno
 * * dropdown
 * * radio
 * * textarea
 *
 * Examples of each field type and their possible configuration parameters are
 * provided in the sample function below.
 *
 * @return array
 */
function onefinmodule_config()
{
    return array(
        // the friendly display name for a payment gateway should be
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'OneFin Third Party Payment Gateway',
        ),
        // a text field type allows for single line text input
        'merchantCode' => array(
            'FriendlyName' => 'Merchant Code',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Merchant Code here',
        ),
        'domain' => array(
            'FriendlyName' => 'Domain',
            'Type' => 'text',
            'Size' => '200',
            'Default' => 'https://sit-pgw.onefin.vn/public/mweb/',
            'Description' => 'Enter your Domain here',
        ),
        // the textarea field type allows for multi-line text input
        'privateKey' => array(
            'FriendlyName' => 'Private Key',
            'Type' => 'textarea',
            'Rows' => '5',
            'Cols' => '60',
            'Description' => 'Enter your Private Key here',
            'Default' => '-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCPyezDlqRTD+Ad
wxfLBFrgyzP1psiJAkrdoHH1ps1KsOyoZzy5I9shYfEMC8rS+kskunlQB+RoBedR
A6pLHH3F00nrwNWKXSVpKT7VF7tC0uAM9JErHu+KOsmjPFEyGNN3/uYSksslP4Ok
dtRWbjYZCV4Su8XZN5araGcBO8rb/VJMBC7YwXWLLwRuakScx3hBbp8+TKKhXx//
Qi+vV7Kan+LSWmWJPS1S9l7YSlOznbajTdbWKjZH5B1GqUceqdoXnuD+Rm7TeGyy
Cv57Bj/Hqiwh3qTtYfcbORVDb6QJR+uyfMEXaSuT2A8VMsHbA4txZHqdufhNLtWa
+5uPekFRAgMBAAECggEAWN/6lDo8f4rEgCDiR/39Hgz7pM7eDLF6DNrrFWdwZMZO
wRhulBDxlQSwtT1ktFs4rw8DhNAcAaAEhjK5w4tswiYC/tFGLCu+v+1ahOQSPw+Q
pPFV+U05yjrj/x19InXt37GSC9Dn97H2cGVyganFjlwX5YRimgyd+HyjjkOi864B
ibHTwUIX9NLOPSgUr+4PIQUQlWeS4/x6zGC5x3wA/xf9waeR+ozunlqW1peiwLDD
Lnix/dKX0MCIYXwgbk32ceLCviciyXArFIxeK5Zq9ntLo1ljn0wSlOyw3k3pCTIX
pKVs3poNZ3XGzLpwfQ8waO+UCgTh5bYBdVoJtSvKMQKBgQDvGlntm8xC9xwrFZB1
y1kOraxDb2CXCMky1rqGTxVpW5O3AT1yKVbPMnbINL/3bD71izkVoClwZvd7TgJO
38fvzBCwOcxVOzmhQh2jwvJ+jS+zh6KOzI1iHisX2phZ/oLa3dNjioJi7331/P0+
xmVaU2Z7M3U9I19oVfRjNtOHcwKBgQCZ8zrkUYXv7LWgSu7HG6IJuaaxfQRpj4ot
6ucgac2YbPkhd6R5NpnXRKo5++Zq/TRpryyXASQaQ4+F7JdI3sG6+VC7vtPvefFC
xk8QzbzN6awucU008F9gelEEsjvG+fCD1SkQrUpoeKZZsRadC5Hyk4OduiTnyiFJ
DIhtQpk7KwKBgCIAtVk9FsdPLQpTfr/Bs2CLAjx00l+oODSqpMwE4x6gj1kvK/XY
OygsHQhLuCEPm8R/kBarODlr6zX12g4tdNl9Q8JL9esJCSENrflj9+hXW7lESLHW
FSUm9SnnRFNIBoPpl+5H/FLljBw3ZixPOoql4aUTpFCVfzPvRVn2qg5RAoGADJwX
nsvupJBG8DIzDKv+wb0rIi6TRfIz5z7uX4FLDckfPtaF6kfGohNFviob3XeP63gl
ttipFF2kS9vtKFLWm3IAYuBmi575W/bSUxYG+PbC26r8H/HwXf6m1DOlIc8nHCVB
j9Qh3BzFw2L17zcbZTsf9LNignnT8B/OrORfmLECgYEAsSXLlp2aJwVN65oaGugD
p5039UUBl46LxNqVJp8yFTO0z5iugI8RZz+NrUdcqOm6l0RSOzoKl9O7cKpkta3E
DthVZYIJxX7+Ryey6iRCzZcF9EihOsq82rkIRXXa2uLaNEYx5T5acOxlChLAP1Q4
aZDiRde2L/Tlyo43dCkUbz0=
-----END PRIVATE KEY-----',
        ),
        'publicKey' => array(
            'FriendlyName' => 'Public Key',
            'Type' => 'textarea',
            'Rows' => '3',
            'Cols' => '60',
            'Description' => 'Enter your Public Key here',
            'Default' => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhR2bsqSd5PTMPjS5L7kG
NbZUMdRyDlrc8Qh+MOYnd2k7ftmgD2bNzROSiU0RHkZm6VkI+yW/2NQWQpDs2n2S
Rl2EhMtTCgpOhugIDJwzJKdkbgNpKIthWKf5URcGV5oACJTr/3R05g8cn141jkdC
bdf/46YWcRIsiJ1+gRStZ/hzfte+cOdsqAjLvrlO03VTBt5PqIjKvGrH1egkp/XN
pZN3UHXEuEdV3GRZ/PdqHVkaRhGrvu+pZUztoEu6Fngx7s7Bh4ExeqWz8xT96jvb
kh9BB8FlpmkGecucoD0LomjvstaWqxFmeqJAE4SKj/+jrO/UOG8DZOIABSdMUBOz
8QIDAQAB
-----END PUBLIC KEY-----',
        ),
    );
}

/**
 * tạo $signature từ $message để gửi kèm khi post to OneFin
 * @param $message
 * @param $private_key_pem
 * @return string
 */
function signMessage($message, $private_key_pem) {
    openssl_sign($message, $signature, $private_key_pem);

    return bin2hex($signature);
}

/**
 * hàm này kiểm tra $signature với $message trả về từ OneFin do post to OneFin
 * @param $message
 * @param $signature
 * @param $public_key_pem
 * @return int|false
 */
function verifySignature($message, $signature, $public_key_pem) {
    $signature = hex2bin($signature);

    $verify_sign = openssl_verify($message, $signature, $public_key_pem);

    return $verify_sign;
}
function curl_post($url, $data=[])
{
    $data_string = json_encode($data);

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$data_string,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);

    return json_decode($response, 1);
}
/**
 * Payment link.
 *
 * Required by third party payment gateway modules only.
 *
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/third-party-gateway/
 *
 * @return string
 */
function onefinmodule_link($params)
{
    $request_url = $_SERVER['REQUEST_URI'];
    logTransaction("onefinmodule", $_POST+['request_url' => $request_url], "Payment link.");

    if ($request_url != "/cart.php?a=complete") {
        if ( ($_SERVER['PHP_SELF'] == "/viewinvoice.php" || $_SERVER['SCRIPT_NAME'] == "/viewinvoice.php")
            && isset($_GET['status'])) {
            return checkPayment($params);
        }

        logTransaction("onefinmodule", $_POST+['request_url' => $request_url], "return not cart complete");
        return;
    }

    // Gateway Configuration Parameters
    $merchantCode = $params['merchantCode'];
    $privateKey = $params['privateKey'];
    $publicKey = $params['publicKey'];
    $domain = $params['domain'];

    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];
//    $currencyCode = "VND";

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $backendURL = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php?id='.$invoiceId;
    $transactionMethod = null;

    $messages = [
        "merchantCode" => $merchantCode,
        "currency" => $currencyCode,
        "amount" => $amount * 100,
        "trxRefNo" => $invoiceId."",
        "backendURL" => $backendURL,
        "responsePageURL" => $returnUrl,
        "mobileNo" => $phone,
        "transactionMethod" => $transactionMethod,
        "actionMethod" => 0, // Spending with card
        "email" => $email
    ];

    $messages = json_encode($messages);
    $signature = signMessage($messages, $privateKey);

    // thực hiện kết nói với onefin để lấy link thanh toán
    $data = ['signature' => $signature, 'messages' => $messages];
    $url = $domain.'generatePayment';

    $result = curl_post($url, $data);
    $data['request_url'] = $request_url;
    $data['url'] = $url;
    $data['result'] = $result;
    logTransaction("onefinmodule", $data, "generatePayment");
//var_dump($data); die;
    $resultMessage = "";
    $paymentURL = "#";
    if (isset($result['errorDTO'])) {
        $resultMessage = $result['errorDTO']['message'];
    } elseif (isset($result['signature'])) {
        $signature = $result['signature'];
        $messages = $result['messages'];
        $verify = verifySignature($messages, $signature, $publicKey);
        if ($verify) {
            $messages = json_decode($messages, 1);
            $paymentURL = $messages['paymentURL'];
        } else {
            $resultMessage = "Signature not match.";
        }
    }
    logTransaction("onefinmodule", ["resultMessage" => $resultMessage ? $resultMessage : "match", "paymentURL" => $paymentURL], "verify signature");

    parse_str(parse_url($paymentURL, PHP_URL_QUERY), $params);

    $htmlOutput = '<form method="get" action="' . $paymentURL . '">';
    foreach ($params as $k => $v) {
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . urlencode($v) . '" />';
    }
    if ($resultMessage) {
        $htmlOutput .= '<p style="text-align: center;"> '.$resultMessage.' </p>';
    }
    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}
function checkPayment($params)
{
    // Gateway Configuration Parameters
    $merchantCode = $params['merchantCode'];
    $privateKey = $params['privateKey'];
    $publicKey = $params['publicKey'];
    $domain = $params['domain'];

    $invoiceId = $params['invoiceid'];

    $messages = [
        'merchantCode' => $merchantCode,
        'trxRefNo' => $invoiceId.""
    ];
    $messages = json_encode($messages);
    $signature = signMessage($messages, $privateKey);

    // thực hiện kết nói với onefin để lấy link thanh toán
    $data = ['signature' => $signature, 'messages' => $messages];
    $url = $domain.'checkPayment';

    $result = curl_post($url, $data);
    $data['url'] = $url;
    $data['result'] = $result;
    logTransaction("onefinmodule", $data, "checkPayment");

    if (isset($result['signature'])) {
        $signature = $result['signature'];
        $messages = $result['messages'];
        $verify = verifySignature($messages, $signature, $publicKey);
        $messages = json_decode($messages, 1);

        if ($verify) {
            if ($messages['statusId']==100) {
                $command = 'UpdateInvoice';
                $postData = array(
                    'invoiceid' => $invoiceId,
                    'status' => 'Paid'
                );
                $adminUsername = null;
                $results = localAPI($command, $postData, $adminUsername);
                logTransaction("onefinmodule", $results, "UpdateInvoice");

                if ($results['result'] == "success") {
                    header('Location: '.$_SERVER['REQUEST_URI']);
                    exit();
                }
            }
        }
    }

    return;
}
/**
 * Refund transaction.
 *
 * Called when a refund is requested for a previously successful transaction.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/refunds/
 *
 * @return array Transaction response status
 */
function onefinmodule_refund($params)
{
    $request_url = $_SERVER['REQUEST_URI'];
    logTransaction("onefinmodule", $_POST+['request_url' => $request_url], "Refund transaction");
    // Gateway Configuration Parameters
    $merchantCode = $params['merchantCode'];
    $privateKey = $params['privateKey'];
    $publicKey = $params['publicKey'];
//    $dropdownField = $params['dropdownField'];
//    $radioField = $params['radioField'];
//    $textareaField = $params['textareaField'];

    // Transaction Parameters
    $transactionIdToRefund = $params['transid'];
    $refundAmount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    // perform API call to initiate refund and interpret result

    return array(
        // 'success' if successful, otherwise 'declined', 'error' for failure
        'status' => 'success',
        // Data to be recorded in the gateway log - can be a string or array
        'rawdata' => $responseData,
        // Unique Transaction ID for the refund transaction
        'transid' => $refundTransactionId,
        // Optional fee amount for the fee value refunded
        'fees' => $feeAmount,
    );
}

/**
 * Cancel subscription.
 *
 * If the payment gateway creates subscriptions and stores the subscription
 * ID in tblhosting.subscriptionid, this function is called upon cancellation
 * or request by an admin user.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/subscription-management/
 *
 * @return array Transaction response status
 */
function onefinmodule_cancelSubscription($params)
{
    $request_url = $_SERVER['REQUEST_URI'];
    logTransaction("onefinmodule", $_POST+['request_url' => $request_url], "Cancel subscription");
    // Gateway Configuration Parameters
    $merchantCode = $params['merchantCode'];
    $privateKey = $params['privateKey'];
    $publicKey = $params['publicKey'];
//    $dropdownField = $params['dropdownField'];
//    $radioField = $params['radioField'];
//    $textareaField = $params['textareaField'];

    // Subscription Parameters
    $subscriptionIdToCancel = $params['subscriptionID'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    // perform API call to cancel subscription and interpret result

    return array(
        // 'success' if successful, any other value for failure
        'status' => 'success',
        // Data to be recorded in the gateway log - can be a string or array
        'rawdata' => $responseData,
    );
}
