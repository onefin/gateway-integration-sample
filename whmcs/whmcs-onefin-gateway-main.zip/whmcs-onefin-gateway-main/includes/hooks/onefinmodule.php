<?php
add_hook('AfterCronJob', 1, function($vars) {
    $gatewayModuleName = "onefinmodule";
    // Fetch gateway configuration parameters.
    $gatewayParams = getGatewayVariables($gatewayModuleName);

    $command = 'GetInvoices';
    $postDataGetInvoices = array(
        'limitnum' => 50,
        'status' => 'Unpaid',
        'paymentmethod' => $gatewayModuleName,
        'orderby' => 'invoicenumber',
    );
    $adminUsername = null; // Optional for WHMCS 7.2 and later

    $results = localAPI($command, $postDataGetInvoices, $adminUsername);
    $postDataGetInvoices['date_start'] = date('Y-m-d H:i:s', strtotime('-1 hour'));
    $postDataGetInvoices['date_end'] = date('Y-m-d H:i:s', strtotime('-5 minutes'));
    $postDataGetInvoices['results'] = $results;

    $merchantCode = $gatewayParams['merchantCode'];
    $privateKey = $gatewayParams['privateKey'];
    $publicKey = $gatewayParams['publicKey'];
    $domain = $gatewayParams['domain'];

    logTransaction($gatewayModuleName, $postDataGetInvoices, "add hook AfterCronJob");
    if ($results['result'] == 'success') {
        foreach ($results['invoices']['invoice'] as $invoice) {
            if ($invoice['created_at'] > $postDataGetInvoices['date_end']) {
                $tmp = (array) $invoice;
                $tmp['date_end'] = $postDataGetInvoices['date_end'];
                logTransaction($gatewayModuleName, $tmp, "add hook AfterCronJob break");
                break;
            }

            $invoiceId = $invoice["id"];

            $messages = [
                'merchantCode' => $merchantCode,
                'trxRefNo' => $invoiceId.""
            ];
            $messages = json_encode($messages);
            $signature = signMessage($messages, $privateKey);

// thực hiện kết nói với onefin để lấy link thanh toán
            $data = ['signature' => $signature, 'messages' => $messages];
            $url = $domain.'checkPayment';

            $result = curl_post($url, $data);
            $data['result'] = $result;

            $transactionStatus = "add hook AfterCronJob checkPayment";
            if (isset($result['signature'])) {
                $signature = $result['signature'];
                $messages = $result['messages'];
                $verify = verifySignature($messages, $signature, $publicKey);
                $messages = json_decode($messages, 1);

                if ($verify) {
                    if ($messages['statusId']==100) {
                        $status = "Paid";
                    } elseif ($messages['statusId']==105) {
                        $status = "Cancelled";
                    } else {
                        $status = "Unpaid";
                    }

                    $command = 'UpdateInvoice';
                    $postDataUpdateInvoice = array(
                        'invoiceid' => $invoiceId,
                        'status' => $status
                    );
                    $adminUsername = null;
                    $results = localAPI($command, $postDataUpdateInvoice, $adminUsername);

                    $data["UpdateInvoice"] = ["postData" => $postDataUpdateInvoice, "result" => $result];
                    $transactionStatus .= " UpdateInvoice";

                    if ($messages['statusId']==100 && $results['result'] == "success") {
                        $transactionId = $messages["transactionId"];
                        $paymentFee = $messages["processingFee"];
                        $paymentAmount = $messages["amount"];

                        addInvoicePayment(
                            $invoiceId,
                            $transactionId,
                            $paymentAmount,
                            $paymentFee,
                            $gatewayModuleName
                        );
                    }
                } else {
                    $transactionStatus .= " verify Signature not match";
                }
            }
            else {
                $transactionStatus .= " errorDTO";
                $command = 'UpdateInvoice';
                $postDataUpdateInvoice = array(
                    'invoiceid' => $invoiceId,
                    'status' => "Cancelled"
                );
                $adminUsername = null;
                localAPI($command, $postDataUpdateInvoice, $adminUsername);
            }
            logTransaction($gatewayParams['name'], $data, $transactionStatus);
        }
    }
});